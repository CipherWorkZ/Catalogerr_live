import os
import atexit
import logging
import time
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.events import EVENT_JOB_EXECUTED, EVENT_JOB_ERROR, EVENT_JOB_SUBMITTED
from dotenv import load_dotenv

from services.tasks import TASK_DEFINITIONS, register_task, TASKS, push_task_event
from services.jobs import job_submitted, job_executed, job_error

# --- Load environment ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
env_path = os.path.join(BASE_DIR, ".env")
load_dotenv(env_path)

# --- Scheduler ---
scheduler = BackgroundScheduler()
scheduler.start()
atexit.register(lambda: scheduler.shutdown(wait=False))

# Register tasks
for task in TASK_DEFINITIONS:
    register_task(task, scheduler, TASKS)

scheduler.add_listener(job_submitted, EVENT_JOB_SUBMITTED)
scheduler.add_listener(job_executed, EVENT_JOB_EXECUTED)
scheduler.add_listener(job_error, EVENT_JOB_ERROR)

logging.info("✅ Worker started and tasks registered.")

push_task_event("start", {"task": "Worker boot"})

# --- Keep process alive ---
try:
    while True:
        time.sleep(60)
except KeyboardInterrupt:
    logging.info("👋 Worker shutting down...")
    scheduler.shutdown()
